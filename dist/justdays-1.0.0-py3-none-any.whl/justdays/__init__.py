from .day import Day
from .period import Period

if __name__=='__main__':
    print(Day())